package com.example

import android.app.Application
import com.example.service.CaptureNotificationHelper

class ScreenCaptureApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CaptureNotificationHelper.createNotificationChannel(this)
    }
}
