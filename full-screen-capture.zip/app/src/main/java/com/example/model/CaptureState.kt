package com.example.model

import android.net.Uri

sealed interface CaptureState {
    data object Idle : CaptureState
    data object RequestingPermission : CaptureState
    data class CountingDown(val remainingSeconds: Int, val totalSeconds: Int) : CaptureState
    data object Capturing : CaptureState
    data class Success(val uri: Uri, val fileName: String, val timestamp: Long) : CaptureState
    data class Error(val message: String) : CaptureState
}
