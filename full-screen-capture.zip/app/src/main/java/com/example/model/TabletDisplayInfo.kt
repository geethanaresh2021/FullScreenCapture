package com.example.model

data class TabletDisplayInfo(
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int,
    val refreshRate: Float,
    val isTablet: Boolean,
    val isLandscape: Boolean
) {
    val resolutionLabel: String
        get() = "${widthPx} × ${heightPx}"

    val aspectRatioLabel: String
        get() {
            if (widthPx <= 0 || heightPx <= 0) return "16:10"
            val gcd = calculateGcd(widthPx, heightPx)
            val w = widthPx / gcd
            val h = heightPx / gcd
            return if (w in 1..32 && h in 1..32) "$w:$h" else String.format(java.util.Locale.US, "%.2f:1", widthPx.toFloat() / heightPx)
        }

    val displayCategory: String
        get() = when {
            widthPx >= 2560 || heightPx >= 2560 -> "High-Res WQXGA+ (Galaxy Tab S7+ Class)"
            widthPx >= 1920 || heightPx >= 1920 -> "Full HD+ Tablet Display"
            else -> "Standard Display"
        }

    private fun calculateGcd(a: Int, b: Int): Int {
        var x = a
        var y = b
        while (y != 0) {
            val t = y
            y = x % y
            x = t
        }
        return if (x == 0) 1 else kotlin.math.abs(x)
    }
}
