package com.example.model

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ScreenshotItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val dateAdded: Long,
    val width: Int,
    val height: Int,
    val sizeBytes: Long,
    val relativePath: String
) {
    val formattedDate: String
        get() {
            val date = Date(dateAdded * 1000L)
            val sdf = SimpleDateFormat("MMM d, yyyy · h:mm:ss a", Locale.getDefault())
            return sdf.format(date)
        }

    val formattedShortDate: String
        get() {
            val date = Date(dateAdded * 1000L)
            val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
            return sdf.format(date)
        }

    val formattedSize: String
        get() {
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1.0 -> String.format(Locale.US, "%.2f MB", mb)
                kb >= 1.0 -> String.format(Locale.US, "%.1f KB", kb)
                else -> "$sizeBytes B"
            }
        }

    val formattedResolution: String
        get() = if (width > 0 && height > 0) "${width} × ${height} px" else "Original PNG"
}
