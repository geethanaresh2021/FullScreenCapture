package com.example.service

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.ServiceCompat
import com.example.data.ScreenshotRepository
import com.example.model.CaptureState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var countdownJob: Job? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private val isCapturing = AtomicBoolean(false)
    private val hasCaptured = AtomicBoolean(false)

    companion object {
        const val ACTION_START_CAPTURE = "com.example.service.action.START_CAPTURE"
        const val ACTION_CANCEL_CAPTURE = "com.example.service.action.CANCEL_CAPTURE"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_COUNTDOWN_SECONDS = "extra_countdown_seconds"
        const val EXTRA_WIDTH = "extra_width"
        const val EXTRA_HEIGHT = "extra_height"
        const val EXTRA_DENSITY = "extra_density"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val thread = HandlerThread("ScreenCaptureBackground")
        thread.start()
        backgroundThread = thread
        backgroundHandler = Handler(thread.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        when (intent.action) {
            ACTION_CANCEL_CAPTURE -> {
                cancelCapture("Capture cancelled by user")
                return START_NOT_STICKY
            }
            ACTION_START_CAPTURE -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val countdownSeconds = intent.getIntExtra(EXTRA_COUNTDOWN_SECONDS, 5)
                val width = intent.getIntExtra(EXTRA_WIDTH, 1920)
                val height = intent.getIntExtra(EXTRA_HEIGHT, 1080)
                val density = intent.getIntExtra(EXTRA_DENSITY, 320)

                if (resultCode == 0 || resultData == null) {
                    CaptureController.updateState(CaptureState.Error("Invalid permission result"))
                    stopSelf()
                    return START_NOT_STICKY
                }

                startForegroundWithNotification(countdownSeconds, countdownSeconds)
                initiateCaptureProcess(resultCode, resultData, countdownSeconds, width, height, density)
            }
        }

        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification(remainingSeconds: Int, totalSeconds: Int) {
        val notification = CaptureNotificationHelper.buildForegroundNotification(
            this,
            remainingSeconds,
            totalSeconds
        )

        val foregroundType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else {
            0
        }

        ServiceCompat.startForeground(
            this,
            CaptureNotificationHelper.NOTIFICATION_ID_FOREGROUND,
            notification,
            foregroundType
        )
    }

    private fun updateForegroundNotification(remainingSeconds: Int, totalSeconds: Int) {
        val notification = CaptureNotificationHelper.buildForegroundNotification(
            this,
            remainingSeconds,
            totalSeconds
        )
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(CaptureNotificationHelper.NOTIFICATION_ID_FOREGROUND, notification)
    }

    private fun initiateCaptureProcess(
        resultCode: Int,
        resultData: Intent,
        countdownSeconds: Int,
        width: Int,
        height: Int,
        density: Int
    ) {
        countdownJob?.cancel()
        countdownJob = serviceScope.launch {
            // Android 14+ (API 34+) requirement:
            // MediaProjection MUST be created AFTER startForeground has been called!
            val mediaProjectionManager =
                getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mediaProjectionManager.getMediaProjection(resultCode, resultData)

            if (projection == null) {
                CaptureController.updateState(CaptureState.Error("Failed to obtain MediaProjection session"))
                stopSelf()
                return@launch
            }
            mediaProjection = projection

            // On Android 14+, callback registration before createVirtualDisplay is MANDATORY
            projection.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    cleanupProjection()
                }
            }, backgroundHandler)

            // Perform countdown if seconds > 0
            if (countdownSeconds > 0) {
                for (remaining in countdownSeconds downTo 1) {
                    CaptureController.updateState(
                        CaptureState.CountingDown(
                            remainingSeconds = remaining,
                            totalSeconds = countdownSeconds
                        )
                    )
                    updateForegroundNotification(remaining, countdownSeconds)
                    vibrateTick()
                    delay(1000L)
                }
            }

            CaptureController.updateState(CaptureState.Capturing)
            updateForegroundNotification(0, countdownSeconds)
            // Tactile shutter buzz
            vibrateShutter()

            // Small delay to ensure any UI animations or overlay countdown finish
            delay(150L)

            // Perform actual display capture
            captureVirtualDisplay(projection, width, height, density)
        }
    }

    private fun captureVirtualDisplay(
        projection: MediaProjection,
        width: Int,
        height: Int,
        density: Int
    ) {
        if (isCapturing.getAndSet(true)) return
        hasCaptured.set(false)

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        val virtual = projection.createVirtualDisplay(
            "ScreenCaptureDisplay",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            backgroundHandler
        )
        virtualDisplay = virtual

        reader.setOnImageAvailableListener({ ir ->
            if (hasCaptured.getAndSet(true)) return@setOnImageAvailableListener

            val image = try {
                ir.acquireLatestImage()
            } catch (e: Exception) {
                null
            }

            if (image == null) {
                hasCaptured.set(false)
                return@setOnImageAvailableListener
            }

            serviceScope.launch(Dispatchers.IO) {
                try {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width

                    val bitmap = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)
                    image.close()

                    val finalBitmap = if (rowPadding == 0) {
                        bitmap
                    } else {
                        val cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height)
                        bitmap.recycle()
                        cropped
                    }

                    // Save to Pictures/FullScreenCapture in original PNG resolution
                    val repository = ScreenshotRepository.getInstance(applicationContext)
                    val result = repository.saveScreenshot(finalBitmap)
                    finalBitmap.recycle()

                    launch(Dispatchers.Main) {
                        if (result != null) {
                            val (uri, fileName) = result
                            CaptureController.updateState(
                                CaptureState.Success(
                                    uri = uri,
                                    fileName = fileName,
                                    timestamp = System.currentTimeMillis()
                                )
                            )
                            CaptureController.emitEvent(
                                CaptureController.CaptureEvent.ScreenshotSaved(uri, fileName)
                            )
                            CaptureNotificationHelper.showCaptureSuccessNotification(
                                applicationContext,
                                uri,
                                fileName
                            )
                        } else {
                            CaptureController.updateState(
                                CaptureState.Error("Failed to save screenshot to MediaStore")
                            )
                            CaptureController.emitEvent(
                                CaptureController.CaptureEvent.Error("Failed to save screenshot")
                            )
                        }
                        cleanupAndStop()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    launch(Dispatchers.Main) {
                        CaptureController.updateState(
                            CaptureState.Error("Error processing captured image: ${e.message}")
                        )
                        cleanupAndStop()
                    }
                }
            }
        }, backgroundHandler)

        // Safety timeout: if no image arrived after 4 seconds, abort cleanly
        serviceScope.launch {
            delay(4000L)
            if (!hasCaptured.get()) {
                CaptureController.updateState(
                    CaptureState.Error("Display capture timeout. Please try again.")
                )
                cleanupAndStop()
            }
        }
    }

    private fun vibrateTick() {
        try {
            val vibrator = getVibrator()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(30)
            }
        } catch (e: Exception) {
            // Ignore if vibration fails
        }
    }

    private fun vibrateShutter() {
        try {
            val vibrator = getVibrator()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(120)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun cancelCapture(reason: String) {
        countdownJob?.cancel()
        CaptureController.updateState(CaptureState.Error(reason))
        cleanupAndStop()
    }

    private fun cleanupProjection() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjection?.stop()
            mediaProjection = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun cleanupAndStop() {
        cleanupProjection()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        cleanupProjection()
        backgroundThread?.quitSafely()
        backgroundThread = null
        backgroundHandler = null
    }
}
