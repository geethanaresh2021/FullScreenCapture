package com.example.service

import android.net.Uri
import com.example.model.CaptureState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object CaptureController {
    private val _captureState = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val captureState: StateFlow<CaptureState> = _captureState.asStateFlow()

    private val _captureEvents = MutableSharedFlow<CaptureEvent>(extraBufferCapacity = 5)
    val captureEvents: SharedFlow<CaptureEvent> = _captureEvents.asSharedFlow()

    fun updateState(state: CaptureState) {
        _captureState.value = state
    }

    fun emitEvent(event: CaptureEvent) {
        _captureEvents.tryEmit(event)
    }

    sealed interface CaptureEvent {
        data class ScreenshotSaved(val uri: Uri, val fileName: String) : CaptureEvent
        data class Error(val message: String) : CaptureEvent
    }
}
