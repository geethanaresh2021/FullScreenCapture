package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.model.CaptureState
import com.example.model.ScreenshotItem
import com.example.service.CaptureController
import com.example.service.ScreenCaptureService
import com.example.ui.ScreenCaptureAppScreen
import com.example.ui.ScreenCaptureViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: ScreenCaptureViewModel by viewModels()

    companion object {
        const val EXTRA_VIEW_IMAGE_URI = "extra_view_image_uri"
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startScreenCaptureService(result.resultCode, result.data!!)
        } else {
            CaptureController.updateState(CaptureState.Error("Screen capture permission was not granted"))
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            launchScreenCapturePrompt()
        } else {
            Toast.makeText(
                this,
                "Notification permission is needed for countdown and capture alerts",
                Toast.LENGTH_SHORT
            ).show()
            launchScreenCapturePrompt()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIntentExtras(intent)

        setContent {
            MyApplicationTheme {
                ScreenCaptureAppScreen(
                    viewModel = viewModel,
                    onRequestCapture = { requestCaptureFlow() },
                    onCancelCapture = { cancelCaptureService() },
                    onShareScreenshot = { shareScreenshot(it) },
                    onOpenExternal = { openInExternalGallery(it) }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntentExtras(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        viewModel.updateDisplayInfo(newConfig)
    }

    private fun handleIntentExtras(intent: Intent?) {
        val uriString = intent?.getStringExtra(EXTRA_VIEW_IMAGE_URI)
        if (!uriString.isNullOrEmpty()) {
            val targetUri = Uri.parse(uriString)
            viewModel.refreshScreenshots()
            val match = viewModel.screenshots.value.find { it.uri == targetUri }
            if (match != null) {
                viewModel.selectScreenshot(match)
                viewModel.openFullscreenPreview(match)
            }
        }
    }

    private fun requestCaptureFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(permission)
                return
            }
        }
        launchScreenCapturePrompt()
    }

    private fun launchScreenCapturePrompt() {
        CaptureController.updateState(CaptureState.RequestingPermission)
        val mediaProjectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
        screenCaptureLauncher.launch(captureIntent)
    }

    private fun startScreenCaptureService(resultCode: Int, data: Intent) {
        val displayInfo = viewModel.displayInfo.value
        val countdown = viewModel.countdownSeconds.value

        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START_CAPTURE
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_COUNTDOWN_SECONDS, countdown)
            putExtra(ScreenCaptureService.EXTRA_WIDTH, displayInfo.widthPx)
            putExtra(ScreenCaptureService.EXTRA_HEIGHT, displayInfo.heightPx)
            putExtra(ScreenCaptureService.EXTRA_DENSITY, displayInfo.densityDpi)
        }

        ContextCompat.startForegroundService(this, serviceIntent)

        // Minimize app if setting is enabled so the user can capture the home screen,
        // split screen apps, or floating pop-ups!
        if (viewModel.minimizeOnCountdown.value) {
            moveTaskToBack(true)
        }
    }

    private fun cancelCaptureService() {
        val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_CANCEL_CAPTURE
        }
        startService(serviceIntent)
        viewModel.resetCaptureState()
    }

    private fun shareScreenshot(item: ScreenshotItem) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, item.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "Share Screenshot"))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not share screenshot: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openInExternalGallery(item: ScreenshotItem) {
        try {
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, "image/png")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(viewIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "No app available to open PNG: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
