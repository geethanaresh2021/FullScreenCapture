package com.example.ui

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.TabletMac
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ScreenshotItem
import com.example.ui.components.CaptureConsole
import com.example.ui.components.DisplayInfoCard
import com.example.ui.components.FullscreenImageViewer
import com.example.ui.components.ScreenshotDetailPane
import com.example.ui.components.ScreenshotGallery

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenCaptureAppScreen(
    viewModel: ScreenCaptureViewModel,
    onRequestCapture: () -> Unit,
    onCancelCapture: () -> Unit,
    onShareScreenshot: (ScreenshotItem) -> Unit,
    onOpenExternal: (ScreenshotItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val captureState by viewModel.captureState.collectAsStateWithLifecycle()
    val countdownSeconds by viewModel.countdownSeconds.collectAsStateWithLifecycle()
    val minimizeOnCountdown by viewModel.minimizeOnCountdown.collectAsStateWithLifecycle()
    val screenshots by viewModel.screenshots.collectAsStateWithLifecycle()
    val selectedScreenshot by viewModel.selectedScreenshot.collectAsStateWithLifecycle()
    val fullscreenScreenshot by viewModel.fullscreenScreenshot.collectAsStateWithLifecycle()
    val displayInfo by viewModel.displayInfo.collectAsStateWithLifecycle()

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    var rightPaneTabIndex by remember { mutableIntStateOf(0) }
    var portraitTabIndex by remember { mutableIntStateOf(0) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("main_screen_scaffold"),
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "App Icon",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "Full Screen Capture",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Native Android MediaProjection · Samsung Galaxy Tab S7+ Edition",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.TabletMac,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${displayInfo.resolutionLabel} px",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            val isWideLayout = maxWidth >= 840.dp || (isLandscape && maxWidth >= 700.dp)

            if (isWideLayout) {
                // Tablet Dual-Pane Landscape Layout
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Left Column: Control Console & Tablet Display Profile
                    Column(
                        modifier = Modifier
                            .width(380.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CaptureConsole(
                            captureState = captureState,
                            selectedCountdown = countdownSeconds,
                            minimizeOnCountdown = minimizeOnCountdown,
                            onCountdownSelected = { viewModel.setCountdown(it) },
                            onMinimizeToggled = { viewModel.setMinimizeOnCountdown(it) },
                            onStartCaptureClick = onRequestCapture,
                            onCancelCaptureClick = onCancelCapture
                        )

                        DisplayInfoCard(displayInfo = displayInfo)
                    }

                    // Right Column: Gallery & Detail Inspector
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Segmented Tab Row for Gallery vs Detail
                        TabRow(
                            selectedTabIndex = rightPaneTabIndex,
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clip(RoundedCornerShape(16.dp))
                        ) {
                            Tab(
                                selected = rightPaneTabIndex == 0,
                                onClick = { rightPaneTabIndex = 0 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Collections,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Gallery Grid (${screenshots.size})")
                                    }
                                }
                            )
                            Tab(
                                selected = rightPaneTabIndex == 1,
                                onClick = { rightPaneTabIndex = 1 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Visibility,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Inspector & Preview")
                                    }
                                }
                            )
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            if (rightPaneTabIndex == 0) {
                                ScreenshotGallery(
                                    screenshots = screenshots,
                                    selectedScreenshot = selectedScreenshot,
                                    onScreenshotClick = {
                                        viewModel.selectScreenshot(it)
                                        rightPaneTabIndex = 1
                                    },
                                    onFullscreenClick = { viewModel.openFullscreenPreview(it) },
                                    onShareClick = onShareScreenshot,
                                    onRefreshClick = { viewModel.refreshScreenshots() },
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                ScreenshotDetailPane(
                                    item = selectedScreenshot,
                                    onFullscreenClick = { viewModel.openFullscreenPreview(it) },
                                    onShareClick = onShareScreenshot,
                                    onOpenExternalClick = onOpenExternal,
                                    onDeleteClick = { viewModel.deleteScreenshot(it) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            } else {
                // Tablet Portrait / Compact Layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    CaptureConsole(
                        captureState = captureState,
                        selectedCountdown = countdownSeconds,
                        minimizeOnCountdown = minimizeOnCountdown,
                        onCountdownSelected = { viewModel.setCountdown(it) },
                        onMinimizeToggled = { viewModel.setMinimizeOnCountdown(it) },
                        onStartCaptureClick = onRequestCapture,
                        onCancelCaptureClick = onCancelCapture
                    )

                    TabRow(
                        selectedTabIndex = portraitTabIndex,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp))
                    ) {
                        Tab(
                            selected = portraitTabIndex == 0,
                            onClick = { portraitTabIndex = 0 },
                            text = { Text("Gallery (${screenshots.size})") }
                        )
                        Tab(
                            selected = portraitTabIndex == 1,
                            onClick = { portraitTabIndex = 1 },
                            text = { Text("Inspector") }
                        )
                        Tab(
                            selected = portraitTabIndex == 2,
                            onClick = { portraitTabIndex = 2 },
                            text = { Text("Display Info") }
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (portraitTabIndex) {
                            0 -> {
                                ScreenshotGallery(
                                    screenshots = screenshots,
                                    selectedScreenshot = selectedScreenshot,
                                    onScreenshotClick = {
                                        viewModel.selectScreenshot(it)
                                        portraitTabIndex = 1
                                    },
                                    onFullscreenClick = { viewModel.openFullscreenPreview(it) },
                                    onShareClick = onShareScreenshot,
                                    onRefreshClick = { viewModel.refreshScreenshots() },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            1 -> {
                                ScreenshotDetailPane(
                                    item = selectedScreenshot,
                                    onFullscreenClick = { viewModel.openFullscreenPreview(it) },
                                    onShareClick = onShareScreenshot,
                                    onOpenExternalClick = onOpenExternal,
                                    onDeleteClick = { viewModel.deleteScreenshot(it) },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            2 -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    DisplayInfoCard(
                                        displayInfo = displayInfo,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Fullscreen Image Dialog with zoom & pan
    fullscreenScreenshot?.let { item ->
        FullscreenImageViewer(
            item = item,
            onDismiss = { viewModel.closeFullscreenPreview() },
            onShare = onShareScreenshot,
            onDelete = { viewModel.deleteScreenshot(it) }
        )
    }
}
