package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High-contrast AMOLED Dark & Light palette for Samsung Galaxy Tab S7+
val CyanPrimary = Color(0xFF00D1FF)
val CyanOnPrimary = Color(0xFF003544)
val CyanPrimaryContainer = Color(0xFF004D63)
val CyanOnPrimaryContainer = Color(0xFFBBE9FF)

val IndigoSecondary = Color(0xFF818CF8)
val IndigoOnSecondary = Color(0xFF1E1B4B)
val IndigoSecondaryContainer = Color(0xFF312E81)
val IndigoOnSecondaryContainer = Color(0xFFE0E7FF)

val EmeraldTertiary = Color(0xFF10B981)
val EmeraldOnTertiary = Color(0xFF064E3B)
val EmeraldTertiaryContainer = Color(0xFF065F46)
val EmeraldOnTertiaryContainer = Color(0xFFA7F3D0)

val DarkSurface = Color(0xFF0B0F19)
val DarkSurfaceVariant = Color(0xFF151D2F)
val DarkBackground = Color(0xFF070A10)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

val AmberCountdown = Color(0xFFF59E0B)
val AmberOnCountdown = Color(0xFF451A03)
