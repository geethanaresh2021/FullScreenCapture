package com.example.ui

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ScreenshotRepository
import com.example.model.CaptureState
import com.example.model.ScreenshotItem
import com.example.model.TabletDisplayInfo
import com.example.service.CaptureController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScreenCaptureViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ScreenshotRepository.getInstance(application)

    val screenshots: StateFlow<List<ScreenshotItem>> = repository.screenshots
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val captureState: StateFlow<CaptureState> = CaptureController.captureState

    private val _countdownSeconds = MutableStateFlow(5)
    val countdownSeconds: StateFlow<Int> = _countdownSeconds.asStateFlow()

    private val _minimizeOnCountdown = MutableStateFlow(true)
    val minimizeOnCountdown: StateFlow<Boolean> = _minimizeOnCountdown.asStateFlow()

    private val _selectedScreenshot = MutableStateFlow<ScreenshotItem?>(null)
    val selectedScreenshot: StateFlow<ScreenshotItem?> = _selectedScreenshot.asStateFlow()

    private val _fullscreenScreenshot = MutableStateFlow<ScreenshotItem?>(null)
    val fullscreenScreenshot: StateFlow<ScreenshotItem?> = _fullscreenScreenshot.asStateFlow()

    private val _displayInfo = MutableStateFlow(calculateDisplayInfo())
    val displayInfo: StateFlow<TabletDisplayInfo> = _displayInfo.asStateFlow()

    init {
        refreshScreenshots()
        observeCaptureEvents()
    }

    fun updateDisplayInfo(configuration: Configuration) {
        _displayInfo.value = calculateDisplayInfo(configuration)
    }

    private fun calculateDisplayInfo(config: Configuration? = null): TabletDisplayInfo {
        val context = getApplication<Application>()
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        var width: Int
        var height: Int
        var density: Int
        var refreshRate = 60f

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val metrics = wm.currentWindowMetrics
            width = metrics.bounds.width()
            height = metrics.bounds.height()
            density = context.resources.configuration.densityDpi
            try {
                @Suppress("DEPRECATION")
                refreshRate = wm.defaultDisplay.refreshRate
            } catch (e: Exception) {
                refreshRate = 120f
            }
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            width = dm.widthPixels
            height = dm.heightPixels
            density = dm.densityDpi
            @Suppress("DEPRECATION")
            refreshRate = wm.defaultDisplay.refreshRate
        }

        val isLandscape = width > height
        val isTablet = (context.resources.configuration.screenLayout and
                Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE

        return TabletDisplayInfo(
            widthPx = width,
            heightPx = height,
            densityDpi = density,
            refreshRate = refreshRate,
            isTablet = isTablet,
            isLandscape = isLandscape
        )
    }

    private fun observeCaptureEvents() {
        viewModelScope.launch {
            CaptureController.captureEvents.collect { event ->
                when (event) {
                    is CaptureController.CaptureEvent.ScreenshotSaved -> {
                        refreshScreenshots()
                        // Automatically select the newly taken screenshot
                        val current = repository.loadScreenshots()
                        val match = current.find { it.uri == event.uri } ?: current.firstOrNull()
                        _selectedScreenshot.value = match
                    }
                    is CaptureController.CaptureEvent.Error -> {
                        // handled by captureState
                    }
                }
            }
        }
    }

    fun setCountdown(seconds: Int) {
        _countdownSeconds.value = seconds
    }

    fun setMinimizeOnCountdown(enabled: Boolean) {
        _minimizeOnCountdown.value = enabled
    }

    fun selectScreenshot(item: ScreenshotItem?) {
        _selectedScreenshot.value = item
    }

    fun openFullscreenPreview(item: ScreenshotItem) {
        _fullscreenScreenshot.value = item
    }

    fun closeFullscreenPreview() {
        _fullscreenScreenshot.value = null
    }

    fun refreshScreenshots() {
        viewModelScope.launch {
            val list = repository.loadScreenshots()
            if (_selectedScreenshot.value == null && list.isNotEmpty()) {
                _selectedScreenshot.value = list.first()
            }
        }
    }

    fun deleteScreenshot(item: ScreenshotItem) {
        viewModelScope.launch {
            repository.deleteScreenshot(item)
            if (_selectedScreenshot.value?.id == item.id) {
                _selectedScreenshot.value = repository.screenshots.value.firstOrNull()
            }
            if (_fullscreenScreenshot.value?.id == item.id) {
                _fullscreenScreenshot.value = null
            }
        }
    }

    fun resetCaptureState() {
        CaptureController.updateState(CaptureState.Idle)
    }
}
