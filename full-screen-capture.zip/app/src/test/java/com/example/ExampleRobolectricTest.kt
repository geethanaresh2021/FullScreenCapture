package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ScreenshotItem
import com.example.model.TabletDisplayInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Full Screen Capture", appName)
    }

    @Test
    fun `tablet display info metrics calculation`() {
        val displayInfo = TabletDisplayInfo(
            widthPx = 2800,
            heightPx = 1752,
            densityDpi = 276,
            refreshRate = 120f,
            isTablet = true,
            isLandscape = true
        )
        assertEquals("2800 × 1752", displayInfo.resolutionLabel)
        assertEquals(true, displayInfo.isTablet)
        assertEquals(true, displayInfo.isLandscape)
    }
}
